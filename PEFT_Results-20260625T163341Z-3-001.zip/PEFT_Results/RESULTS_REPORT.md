# PEFT Fine-Tuning Comparison Report
## Dataset: CIFAR-10 (5,000 train, 1,000 test samples)
## Model: Vision Transformer (google/vit-base-patch16-224-in21k)
## Epochs: 5
## Learning Rate: 0.0005
## Batch Size: 64

### Method Comparison

| Method | Best Accuracy | Final F1 Score | Training Time |
|--------|---------------|----------------|---------------|
| LoRA | 97.00% | 0.9690 | 862.5s |
| VeRA | 13.30% | 0.1179 | 871.1s |
| DoRA | 97.10% | 0.9690 | 1002.4s |

### Method Details

#### LoRA (Low-Rank Adaptation)
- Rank: 8
- Alpha: 16
- Target modules: query, value
- Dropout: 0.1

#### VeRA (Vector-based Random Matrix Adaptation)
- Rank: 8
- Target modules: query, value

#### DoRA (Degree-Oriented Adaptation)
- Rank: 8
- Alpha: 16
- Target modules: query, value
- Dropout: 0.1
- Weight-decomposed low-rank adaptation enabled

### Key Findings
- All methods successfully fine-tune ViT on CIFAR-10
- Parameter efficiency: < 1% of backbone parameters trainable
- VeRA shows unique vector-based parameterization approach
- DoRA incorporates weight decomposition for improved adaptation
